package com.backend.clinicaodontologica.exceptions;

public class ResourcesNotFoundException  extends Exception{
    public ResourcesNotFoundException(String message) {
        super(message);
    }
}
