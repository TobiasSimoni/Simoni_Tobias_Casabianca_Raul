package com.backend.clinicaodontologica.service;

import com.backend.clinicaodontologica.dto.entrada.turno.TurnoEntradaDto;
import com.backend.clinicaodontologica.dto.salida.turno.TurnoSalidaDto;
import com.backend.clinicaodontologica.exceptions.BadRequestException;

public interface ITurnoService {


    TurnoSalidaDto registrarturno(TurnoEntradaDto turnoEntradaDto) throws BadRequestException;
}
