package com.backend.clinicaodontologica.dto.entrada.turno;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TurnoEntradaDto {
    @NotNull(message = "El paciente no puede ser nulo")
    private long pacienteid;
    @NotNull(message = "El odontologo no puede ser nulo")
    private long odontologoid;

    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "yyyy-MM-dd")
    @FutureOrPresent(message = "La fehca no puede ser anterior al dia de hoy")
    @NotNull(message = "Debe especificarse la fecha y hora del turno")
    private LocalDateTime fechayhora;

    public TurnoEntradaDto() {
    }

    public TurnoEntradaDto(long pacienteid, long odontologoid, LocalDateTime fechayhora) {
        this.pacienteid = pacienteid;
        this.odontologoid = odontologoid;
        this.fechayhora = fechayhora;
    }

    public long getPacienteid() {
        return pacienteid;
    }

    public void setPacienteid(long pacienteid) {
        this.pacienteid = pacienteid;
    }

    public long getOdontologoid() {
        return odontologoid;
    }

    public void setOdontologoid(long odontologoid) {
        this.odontologoid = odontologoid;
    }

    public LocalDateTime getFechayhora() {
        return fechayhora;
    }

    public void setFechayhora(LocalDateTime fechayhora) {
        this.fechayhora = fechayhora;
    }
}
